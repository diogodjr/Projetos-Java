import utils.ValidadorCPF;

public class Cliente {
    private String cpf;
    private String nome;
    private String username;
    private Integer idade;

    public Cliente(String cpf, String nome, String username, Integer idade) {
        validarIdade(idade);
        if (!ValidadorCPF.validarCpf(cpf)) {
            throw new IllegalArgumentException("CPF inválido");
        }
        this.cpf = cpf;
        this.nome = nome;
        this.username = username;
        this.idade = idade;
    }

    public String getCpf() {
        return cpf;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        validarIdade(idade);
        this.idade = idade;
    }

    private void validarIdade(Integer idade) {
        if (idade < 0 || idade == null) {
            throw new IllegalArgumentException("A idade deve ser um número válido e maior ou igual a zero.");
        }
    }
}