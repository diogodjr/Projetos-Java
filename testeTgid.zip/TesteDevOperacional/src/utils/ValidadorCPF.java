package utils;

public class ValidadorCPF {

	public static boolean validarCpf(String cpf) {
		if (cpf == null || !cpf.matches("\\d{11}")) {
			return false;
		}

		cpf = cpf.replaceAll("[^0-9]", ""); // Remove caracteres não numéricos
		if (cpf.length() != 11 || cpf.equals("00000000000") || cpf.equals("11111111111") || cpf.equals("22222222222")
				|| cpf.equals("33333333333") || cpf.equals("44444444444") || cpf.equals("55555555555")
				|| cpf.equals("66666666666") || cpf.equals("77777777777") || cpf.equals("88888888888")
				|| cpf.equals("99999999999"))
			return false;

		int[] digitos = new int[11];
		for (int i = 0; i < 11; i++) {
			digitos[i] = Integer.parseInt(cpf.substring(i, i + 1));
		}

		if (verificarDigitosRepetidos(digitos)) {
			return false;
		}

		int digitoVerificador1 = calcularDigitoVerificador(digitos, 9);
		int digitoVerificador2 = calcularDigitoVerificador(digitos, 10);

		return digitos[9] == digitoVerificador1 && digitos[10] == digitoVerificador2;
	}

	private static boolean verificarDigitosRepetidos(int[] digitos) {
		for (int i = 1; i < 11; i++) {
			if (digitos[i] != digitos[0]) {
				return false;
			}
		}
		return true;
	}

	private static int calcularDigitoVerificador(int[] digitos, int pesoMaximo) {
		int soma = 0;
		int peso = pesoMaximo + 1;
		for (int i = 0; i < pesoMaximo; i++) {
			soma += digitos[i] * peso;
			peso--;
		}
		int resto = soma % 11;
		return (resto < 2) ? 0 : 11 - resto;
	}

}
